<?php 

//Register User
if (isset($_POST['regu'])) {
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];
 $phone = $_POST['phone'];
 $mod = $_POST['mod'];
 $type = $_POST['type'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {

  if ($mod == 1) {
  $sql = "INSERT INTO `users`(`Fullname`, `Email_Address`, `Phone_Number`, `User_Type`, `Password`) VALUES ('$fname','$email','$phone','User',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: index.html?userregistration=success");
  }else{
   $sql = "INSERT INTO `users`(`Fullname`, `Email_Address`, `Phone_Number`, `User_Type`, `Password`) VALUES ('$fname','$email','$phone','$type',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: index.php?userregistration=success");
 }
 }else{
  echo "Passwords do not match.";
 }
}

//Book Appointment
if (isset($_POST['booka'])) {
 $uid = $_POST['uid'];
 $title = $_POST['title'];
 $date = $_POST['date'];
 $time = $_POST['time'];
 $details = $_POST['details'];

 require_once 'dbconnection.inc.php';

   $sql = "INSERT INTO `appointments`(`User_ID`, `Title`, `Date`, `Time`, `Details`, `Status`) VALUES ('$uid','$title','$date','$time','$details','Pending')";
     mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index1.php?makeappointment=success");
}

//Delete Functions

        if($_REQUEST['action'] == 'deleteU' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_REQUEST['id'];
        $sql = "DELETE FROM `users` WHERE `User_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: index.php?deleteuser=success");
        }

        if($_REQUEST['action'] == 'deleteA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $deleteItem = $_REQUEST['id'];
        $sql = "DELETE FROM `appointments` WHERE `Appointment_ID` = '$deleteItem'";
        mysqli_query($conn, $sql); 
        header("Location: index.php?deletappointment=success");
        }

//Update Functions

        if($_REQUEST['action'] == 'approveA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $updateItem = $_REQUEST['id'];
        $sql = "UPDATE `appointments` SET `Status`='Approved' WHERE `Appointment_ID`='$updateItem'";
        mysqli_query($conn, $sql); 
        header("Location: index.php?approveappointment=success");
        }
        
        if($_REQUEST['action'] == 'disapproveA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $updateItem = $_REQUEST['id'];
        $sql = "UPDATE `appointments` SET `Status`='Disapproved' WHERE `Appointment_ID`='$updateItem'";
        mysqli_query($conn, $sql); 
        header("Location: index.php?approveappointment=success");
        }

        if($_REQUEST['action'] == 'cancelA' && !empty($_REQUEST['id'])){ 
        require_once 'dbconnection.inc.php';
        $updateItem = $_REQUEST['id'];
        $sql = "UPDATE `appointments` SET `Status`='Cancelled' WHERE `Appointment_ID`='$updateItem'";
        mysqli_query($conn, $sql); 
        header("Location: index1.php?cancelappointment=success");
        }

//Update User
if (isset($_POST['upu'])) {
 $uid = $_POST['uid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];
 $phone = $_POST['phone'];
 $mod = $_POST['mod'];
 $type = $_POST['type'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {
  if ($mod == 1) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index.php?updateadministrator=success");
  }else{
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index1.php?updateuser=success");
 }
 }else{
  echo "Passwords do not match.";
 }
}

 ?>