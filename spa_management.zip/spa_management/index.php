<?php
require_once 'dbconnection.inc.php';
session_start();

if (!isset($_SESSION['Email']) && !isset($_SESSION['adminname'])) {
    header("Location: index.html");
}else{
  $filter = $_SESSION['adminname'];
  $query=mysqli_query($conn,"SELECT * FROM `users` WHERE `User_ID`='$filter'")or die(mysqli_error());
  $row=mysqli_fetch_array($query);
}
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Spa Management System - Administrator Homepage</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
   </head>

           <style type="text/css">
        
          table{
    align-items: center;
  }

   th, tr, td{
    padding: 10px 15px;
  }
    </style>

            <script type="text/javascript">
function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData();
})  
</script>

            <script type="text/javascript">
function printData1()
{
   var divToPrint=document.getElementById("printTable1");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData();
})  
</script>

   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <div class="full_bg">
         <!-- header -->
         <header class="header-area">
            <div class="container">
               <div class="row d_flex">
                  <div class=" col-md-3 col-sm-3">
                     <div class="logo">
                        <a href="index.php">Spa Management</a>
                     </div>
                  </div>
                  <div class="col-md-9 col-sm-9">
                     <div class="navbar-area">
                        <nav class="site-navbar">
                           <ul>
                              <li><a class="active" href="index.php">Home</a></li>
                              <li><a href="#about">About</a></li>
                              <li><a href="#contact">Contact us</a></li>
                              <li class="d_none"><a href="logout.php"><i class="fa fa-user" aria-hidden="true"></i> Logout</a></li>
                           </ul>
                           <button class="nav-toggler">
                           <span></span>
                           </button>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <!-- end header inner -->
         <!-- top -->
         <div class="slider_main">
            <!-- carousel code -->
            <div id="banner1" class="carousel slide">
               <div class="carousel-inner">
                  <!-- first slide -->
                  <div class="carousel-item active">
                     <div class="container">
                        <div class="carousel-caption relative">
                           <div class="row d_flex">
                              <div class="col-md-5">
                                 <div class="creative">
                                    <h1>Welcome <br> <?php echo $row['Fullname']; ?> </h1>
                                    <p>Ease Your Mind...</p>
                                    <a class="read_more" href="#contact">Contact us</a>
                                    <a class="read_more" href="#about">Read More</a>
                                 </div>
                              </div>
                              <div class="col-md-7">
                                 <div class="row mar_right">
                                    <div class="col-md-12">
                                       <div class="agency">
                                          <figure><img src="images/home1.jpg" alt="#"/></figure>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
      <!-- end banner -->
       <!-- about -->
      <div id="about" class="about">
         <div class="container_width">
            <div class="row d_flex grig">
               <div class="col-md-6">
                  <div class="about_img">
                     <figure><img src="images/about1.jpg" alt="#"/>
                     </figure>
                  </div>
               </div>
               <div class="col-md-6 order">
                  <div class="titlepage text_align_left">
                     <h2>About Us</h2>
                     <p>Welcome to our Spa Management System, we are readily prepared to provide you with ease of mind and body. Book an appointment and we will respond to you within 24 working hours. Thank you for visiting, and we hope to see you soon!</p>
                     <a class="read_more" href="#testimonial">What Others Say ?</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end about -->
      <!-- appointment -->
      <div id="start" class="appointment">
         <div class="container">
            <div class="row">
               <div class="col-md-12 ">
                  <div class="titlepage text_align_center">
                     <h2>Administrator Module</h2>
                         <p>Register</p>
                  </div>
               </div>
               <div class="col-md-12">
                  <form id="request" class="main_form" action="insertion.inc.php" method="POST">
                     <div class="row">
                        <div class="col-md-6 ">
                           <input class="form_control" placeholder="Fullname" type="text" name="fname" required> 
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Email Address" type="email" name="email" required> 
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Phone Number" type="text" name="phone" required> 
                        </div>
                        <div class="col-md-6">
                           <select class="form_control" name="type" required>
                           <option value="" disabled selected>Select A User Type</option>
                           <option value="Administrator">Administrator</option>
                           <option value="User">User</option>
                           </select>                          
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Password" type="password" name="password" required>                          
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Confirm Password" type="password" name="cpassword" required>   
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn" name="regu">Register</button>
                        </div>
                     </div>
                  </form>
               </div>
               <br>
               <br>
            </div>
            <div class="row">
                              <div class="col-md-12 ">
                  <div class="titlepage text_align_center">
                     <p>Update My Details</p>
                  </div>
               </div>
               <div class="col-md-12">
                  <form id="request" class="main_form" action="insertion.inc.php" method="POST">
                     <div class="row">
                        <div class="col-md-6 ">
                           <input class="form_control" placeholder="Fullname" type="text" name="fname" required> 
                           <input value="<?php echo $filter; ?>" type="hidden" name="uid" required> 
                           <input value="1" type="hidden" name="mod" required>
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Email Address" type="email" name="email" required> 
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Phone Number" type="text" name="phone" required> 
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Password" type="password" name="password" required>                          
                        </div>
                        <div class="col-md-6">
                           <input class="form_control" placeholder="Confirm Password" type="password" name="cpassword" required>   
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn" name="upu">Update</button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <!-- end appointment -->
      <!-- customers -->
      <div id="testimonial" class="customers">
         <div class="clients_bg">
            <div class="container">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="titlepage text_align_center">
                        <h2>Database</h2>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- start slider section -->
                     <div class="row">
               <div class="col-md-12">
                    <div class="titlepage">
                     <p>~ Users</p>
                  </div>
               <table id="printTable">
<tr style="text-align: left;
  padding: 8px;">
<th style="text-align: left;
  padding: 8px;">User ID</th>
<th style="text-align: left;
  padding: 8px;">Fullname</th>
  <th style="text-align: left;
  padding: 8px;">Email Address</th>
 <th style="text-align: left;
  padding: 8px;">Phone Number</th>
  <th style="text-align: left;
  padding: 8px;">Module</th>
   <th style="text-align: left; padding: 8px;"></th>
</tr>

<?php
$conn = mysqli_connect("localhost", "root", "", "spa_management");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT `User_ID`, `Fullname`, `Email_Address`, `Phone_Number`, `User_Type` FROM `users`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo($row["User_ID"]); ?></td>
<td><?php echo($row["Fullname"]); ?></td>
<td><?php echo($row["Email_Address"]); ?></td>
<td><?php echo($row["Phone_Number"]); ?></td>
<td><?php echo($row["User_Type"]); ?></td>
<td><button class="send_btn" onclick="return confirm('Are you sure to delete this user?')?window.location.href='insertion.inc.php?action=deleteU&id=<?php echo($row["User_ID"]); ?>':true;" title='Delete User'>Delete</button></td>
</tr>
<?php
}
} else { echo "No results"; }
$conn->close();
?>

</table>
                <div>
                  <div><a href="#" class="send_btn" onclick="printData();">Print</a></div>
                </div>
               </div>
                              <div class="col-md-12">
                    <div class="titlepage">
                     <p>~ Appointments</p>
                  </div>
              <table id="printTable1">
<tr style="text-align: left;
  padding: 8px;">
<th style="text-align: left;
  padding: 8px;">Appointment ID</th>
<th style="text-align: left;
  padding: 8px;">User ID</th>
  <th style="text-align: left;
  padding: 8px;">Title </th>
  <th style="text-align: left;
  padding: 8px;">Details </th>
  <th style="text-align: left;
  padding: 8px;">Date </th>
  <th style="text-align: left;
  padding: 8px;">Time </th>
  <th style="text-align: left;
  padding: 8px;">Status </th>
  <th style="text-align: left; padding: 8px;"></th>
  <th style="text-align: left; padding: 8px;"></th>
</tr>

<?php
$conn = mysqli_connect("localhost", "root", "", "spa_management");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT `Appointment_ID`, `User_ID`, `Title`, `Date`, `Time`, `Details`, `Status` FROM `appointments`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo($row["Appointment_ID"]); ?></td>
<td><?php echo($row["User_ID"]); ?></td>
<td><?php echo($row["Title"]); ?></td>
<td><?php echo($row["Details"]); ?></td>
<td><?php echo($row["Date"]); ?></td>
<td><?php echo($row["Time"]); ?></td>
<td><?php echo($row["Status"]); ?></td>
<td><button class="send_btn" onclick="return confirm('Are you sure to approve this appointment?')?window.location.href='insertion.inc.php?action=approveA&id=<?php echo ($row['Appointment_ID']); ?>':true;" title='Approve Appointment'>Approve</button></td>
<td><button class="send_btn" onclick="return confirm('Are you sure to disapprove this appointment?')?window.location.href='insertion.inc.php?action=disapproveA&id=<?php echo ($row['Appointment_ID']); ?>':true;" title='Disapprove Appointment'>Disapprove</button></td>
</tr>
<?php
}
} else { echo "No results"; }
$conn->close();
?>

</table>
                <div>
                  <div><a href="#" class="send_btn" onclick="printData1();">Print</a></div>
                </div>
               </div>
      </div>
      <!-- end customers -->
      <!--  footer -->
      <footer id="contact">
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-6">
                     <div class="row">
                        <div class="col-lg-6 col-md-12">
                           <div class="hedingh3 text_align_left">
                              <h3>About</h3>
                              <p> Welcome to our Spa Management System, we are readily prepared to provide you with ease of mind and body. Book an appointment and we will respond to you within 24 working hours. Thank you for visiting, and we hope to see you soon!</p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="row">
                        <div class="col-lg-6 col-md-12">
                           <div class="hedingh3 text_align_left">
                              <h3>Menu</h3>
                              <ul class="menu_footer">
                                 <li><a href="index.php">Home</a></li>
                                 <li><a href="#about">About Us</a></li>
                                 <li><a href="#testimonial">Testimonial</a></li>
                                 <li><a href="$start">Get Started</a></li>
                                 <li><a href="#contact">Contact Us</a></li>
                              </ul>
                           </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                           <div class="hedingh3  text_align_left">
                              <ul class="top_infomation">
                                 <li><i class="fa fa-phone" aria-hidden="true"></i>
                                    +254 (0)7123 4567890
                                 </li>
                                 <li><i class="fa fa-envelope" aria-hidden="true"></i>
                                    <a href="">spa.project@gmail.com</a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>© 2023 All Rights Reserved.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/bootstrap-datepicker.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>